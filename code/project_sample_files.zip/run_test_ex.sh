python3 main_ex.py $1
