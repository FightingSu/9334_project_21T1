#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
This program reads in an input, triples it and then writes the result
to a file. 
"""

import sys 
import os

def main(s):
       
    # Open the config file para_*.txt to obtain the rate of
    # the faster server 
    config_folder = 'config'
    para_file = os.path.join(config_folder,'para_'+s+'.txt')
    
    with open(para_file,'r') as file:
        f = file.readline()
    
    # As a demonstration, write to a file called dummy_*.txt
    # in the output directory 
    out_folder = 'output'
    out_file = os.path.join(out_folder,'dummy_'+s+'.txt')
    
    with open(out_file,'w') as file:
        file.writelines('The rate the faster server is '+f+'\n')
    
if __name__ == "__main__":
   main(sys.argv[1])